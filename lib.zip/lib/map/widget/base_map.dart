import 'package:flutter/material.dart';

abstract class MapPage extends StatelessWidget {
  const MapPage(this.title);

  final String title;
}
